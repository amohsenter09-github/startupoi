var aws = require('aws-sdk');
var request = require('request');
var ses = new aws.SES();
var config = require("./config.json");

function sendEmail(to, body, completedCallback) {
    console.log("STARTUPOI - SEND EMAIL TEMPORARY PASSWORD CODE START");
    var eParams = {
        Destination: {
            ToAddresses: [to]
        },
        Message: {
            Body: {
                Html: {
                    Charset: "UTF-8",
                    Data: body
                }
            },
            Subject: {
                Data: "Your temporary password"
            }
        },
        Source: 'noreply@startupoi.com'
    };

    ses.sendEmail(eParams).promise();
    console.log("STARTUPOI - SEND EMAIL TEMPORARY PASSWORD CODE START");
    completedCallback();
};

exports.handler = async(event, context, callback) => {
    console.log("STARTUPOI - TRIGGER PRE SIGN UP - START");
    console.log('STARTUPOI - TRIGGER PRE SIGN UP - EVENT ', event);
    
    if (event.request.userAttributes.email && event.request.userAttributes.hasOwnProperty('custom:temporary_password')) {
        var body = {};
        body.uuid = event.userName;
        body.email = event.request.userAttributes.email;
    
        if (event.request.userAttributes.given_name) {
            body.firstName = event.request.userAttributes.given_name;
        }
        
        if (event.request.userAttributes.family_name) {
            body.lastName = event.request.userAttributes.family_name;
        }
        
        if (event.request.userAttributes.locale) {
            body.appLanguageCode = event.request.userAttributes.locale;
        }
        
        if (event.request.userAttributes.nickname) {
            body.userName = event.request.userAttributes.nickname;
        }
        
        if (event.request.userAttributes.hasOwnProperty('custom:facebook_user_id')) {
            body.facebookUserId = event.request.userAttributes['custom:facebook_user_id'];
        }
        
        var options = {
            'method': 'POST',
            'url': `${config.accountservice}/api/v1/user/newFromAWSCognito`,
            'headers': {'Content-Type': 'application/json'},
            body: JSON.stringify(body)
        };
        
        console.log("Body payload of the request is ", options);
    
        request(options, function (error, response, body) {
            console.log("Error, body of the request is ", error, body);
            if (error) throw new Error(error);
    
                //var message = "Your temporary password is " + event.request.userAttributes['custom:temporary_password'];
                /*var tempPassword = event.request.userAttributes['custom:temporary_password'];
                var message = `
                <div style="padding: 0 10px 0 10px; max-width: 400px; margin: auto;">
                    <div>
                        <img src="https://startupoi-dev.s3.ap-southeast-1.amazonaws.com/email/logo_name.png" alt="" width="180"
                            height="58" />
                    </div>
                    <div style="padding: 0 10px 0 10px;">
                        <p style="font-size: 1.4em">Welcome to StartupOi!</p>
                        <img src="https://startupoi-dev.s3.ap-southeast-1.amazonaws.com/email/artboard.png" alt="" width="300"
                            height="242" style="display: block; margin: 0 auto;" />
                
                        <p style="text-align: center; color: #3D3A45; font-size: 1.1em; padding: 0 20px 0 20px"> Your temporary password is</p>
                        <p style="text-align: center; color: #121212; font-size: 1.3em; padding: 0 70px 0 70px"> ${tempPassword} </p>
                        <div style="margin-top: 40px;">
                        </div>
                    </div>
                </div>
                `;
                sendEmail(event.request.userAttributes.email, message, function() {
                    // callback(null, event);
                });*/
        });
    }

    callback(null, event);
    console.log("STARTUPOI - TRIGGER PRE SIGN UP - END");
};
