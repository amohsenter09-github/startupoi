var request = require('request');
var config = require("./config.json");

exports.handler = (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    callback(null, event);

    // var uuid = event.request.userAttributes.sub;
    // var email = event.request.userAttributes.email;

    // var options = {
    //     'method': 'POST',
    //     'url': `${config.accountservice}/api/v1/user/newFromAWSCognito`,
    //     'headers': {
    //         'Content-Type': 'application/json'
    //     },
    //     body: JSON.stringify({
    //         "uuid": uuid,
    //         "email": email
    //     })
    // };
    
    // request(options, function (error, response) {
    //     if (error) throw new Error(error);
    //     callback(null, event);
    // });
}
