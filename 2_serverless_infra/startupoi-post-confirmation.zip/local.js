var request = require('request');
var config = require("./config.json");

var options = {
    'method': 'POST',
    'url': `${config.accountservice}/api/v1/user/newFromAWSCognito`,
    'headers': {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
        "uuid": "1235235-435dsf-234213",
        "email": "abc8@b.com"
    })

};

request(options, function (error, response) {
    if (error) throw new Error(error);
});
